# Rainbow Monster Sanctuary asset pipeline

This folder preserves both supplied images unchanged. `layout.json` maps the
newer seven-panel image, while `layout-overview.json` records the older board.
Run `Build-Assets.ps1` in PowerShell to
regenerate `output/frames` and `output/manifest.json` from `layout.json`.
The build also makes one 4-column, 5-row action sheet per monster in
`output/sheets`; rows are idle, feed, clean, play, sleep.

Extract the ZIP, then double-click `rainbow-pipeline/preview.html` to play
every extracted action and see its real frame count. Keep the `output` folder
beside the page. The preview's movement and particle effect are programmatic
and do not alter the supplied images. Run `node test-preview.mjs` in the Game
workspace to check all seven cards and all 140 frame paths.

The new source is a semi-transparent 1536×1024 composite with four poses for
each of five actions. It is substantially better than the old opaque board,
including Moonmoth's fourth sleep pose. Its colored panel matte, glow, and
some sprites crossing implied cell divisions still require manual review. The
extractor removes pixels below the configured alpha threshold. Do not replace
the game's existing artwork with unreviewed frames automatically.

## Observed assets

| Monster | Idle | Feed | Clean | Play | Sleep | Status |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| Emberhorn | 4 | 4 | 4 | 4 | 4 | Review fire glow and crop edges |
| Sparkfox | 4 | 4 | 4 | 4 | 4 | Review tail and panel matte |
| Sunfeather | 4 | 4 | 4 | 4 | 4 | Review wings and effect pixels |
| Leafsprite | 4 | 4 | 4 | 4 | 4 | Review tail and crop edges |
| Tidefin | 4 | 4 | 4 | 4 | 4 | Review fins, water effects, and panel matte |
| Nightwhisk | 4 | 4 | 4 | 4 | 4 | Review dark outline and tail |
| Moonmoth | 4 | 4 | 4 | 4 | 4 | Review wings and panel matte |

The older board's labels said four sleep frames but showed only three. The new
image supplies four visible sleep poses per monster. No frame is invented.

## Needed to finish the game-ready pack

Original individual transparent sheets would allow clean extraction where
sprites overlap their implied cells. The current cutouts and animation preview
still need visual approval before the game art is replaced.
